import { ProfileData } from './types';

export const RESUME_DATA: ProfileData = {
  name: "Gabriel Lau",
  title: "Infraestrutura & Automação | SysAdmin | DevOps",
  location: "Santa Cruz do Sul - Rio Grande do Sul - Brazil",
  contact: {
    email: "Gabriel700520@hotmail.com",
    phone: "(21) 97381-9979"
  },
  socials: [
    {
      platform: "LinkedIn",
      url: "#", // Placeholder as original URL wasn't provided in text
      icon: "linkedin"
    },
    {
      platform: "GitHub",
      url: "#", // Placeholder
      icon: "github"
    }
  ],
  summary: "Profissional de Infraestrutura e Automação com 2 anos de experiência em Hosting Operations na Equinix. Especialista em monitoramento (Zabbix), administração de Windows Server (Active Directory, Hyper-V) e automação de processos via scripting. Busco vaga desafiadora na área de SysAdmin ou Junior DevOps para aplicar meu conhecimento em otimização de ambientes e observabilidade. Inglês fluente.",
  projects: [
    // Infra Projects
    {
      title: "Monitoramento Base Windows Enterprise",
      description: "Desenvolvimento de template completo para monitoramento escalável de servidores Windows. Utiliza Low Level Discovery (LLD) para detectar automaticamente discos e interfaces de rede, eliminando configuração manual.",
      tags: ["Zabbix 5.0", "XML", "LLD", "Windows Performance"],
      icon: "monitor",
      category: "infra",
      features: [
        "Discovery automático de sistemas de arquivos e interfaces de rede",
        "Monitoramento preditivo de CPU (Load/Utilização) e Swap",
        "Detecção de reboots inesperados via EventLog (ID 6008)",
        "Triggers inteligentes para serviços críticos (Update, Time, Server)"
      ]
    },
    {
      title: "Automação de Compliance e Segurança",
      description: "Implementação de verificações de conformidade automatizadas via Zabbix Agent Active. O sistema valida configurações de segurança, versionamento de software e políticas corporativas em tempo real.",
      tags: ["PowerShell", "Security", "Compliance", "Active Agent"],
      icon: "shield",
      category: "infra",
      features: [
        "Validação de Account Lockout Policy e status do UAC",
        "Verificação de versão do PowerShell (>5.1) e Agente Puppet",
        "Checagem de sincronia NTP com servidores Equinix",
        "Monitoramento de serviços de segurança (Trend Micro, Symantec)"
      ]
    },
    {
      title: "Self-Healing e Automação de Serviços",
      description: "Sistema de autorrecuperação (Self-Healing) que detecta serviços parados e tenta reiniciá-los automaticamente antes de alertar a operação, reduzindo MTTR e ruído de alertas.",
      tags: ["Automation", "Self-Healing", "Scripting", "ServiceNow"],
      icon: "refresh",
      category: "infra",
      features: [
        "Script PowerShell para start automático de serviços (net start)",
        "Lógica de contagem de falhas (alertar apenas após X tentativas)",
        "Monitoramento granular de consumo de CPU por processo (ex: zabbix_agent2)",
        "Integração de alertas para abertura de tickets"
      ]
    },
    {
      title: "Diagnóstico de Rede e Tarefas Remotas",
      description: "Ferramentas avançadas para troubleshooting e gerenciamento remoto distribuído. Permite testar conectividade de rede a partir da visão do servidor e agendar manutenções.",
      tags: ["Network", "TCP/IP", "Task Scheduler", "Diagnostics"],
      icon: "network",
      category: "infra",
      features: [
        "Script TCP Client para teste de conectividade (Telnet) via Zabbix",
        "Criação e gerenciamento de Tarefas Agendadas (Schtasks) remotamente",
        "Verificação de portas críticas (ex: TS 3389)",
        "Coleta de inventário e metadados via WMI e Puppet Facts"
      ]
    },
    // Web Projects
    {
      title: "Redesign Amazon AWS (Clone)",
      description: "Desenvolvimento de uma landing page complexa baseada na Amazon AWS, focada em fidelidade visual, semântica HTML5 e responsividade avançada utilizando CSS Grid e Flexbox.",
      tags: ["HTML5", "CSS3", "CSS Grid", "Responsive Design"],
      icon: "globe",
      category: "web",
      features: [
        "Layout totalmente responsivo com menu mobile interativo (CSS-only)",
        "Uso intensivo de SVGs e gradientes para fidelidade visual",
        "Estrutura semântica (Header, Main, Section, Footer)",
        "Tabelas de preços e formulários de contato estilizados"
      ]
    },
    {
      title: "Arquitetura LTDA Portfolio",
      description: "Site de portfólio para escritório de arquitetura com design moderno e minimalista. Foco em experiência do usuário (UX) com transições suaves e galeria de imagens.",
      tags: ["CSS Animations", "Flexbox", "Glassmorphism", "UX/UI"],
      icon: "palette",
      category: "web",
      features: [
        "Galeria de imagens em Grid interativa com efeitos de hover",
        "Menu lateral fixo com efeito de Glassmorphism (Backdrop blur)",
        "Botões com micro-interações e transições suaves",
        "Design responsivo adaptável para mobile e desktop"
      ]
    },
    {
      title: "Portal de Turismo & Reservas",
      description: "Landing page funcional para guia de turismo, integrando sistemas de busca externos e navegação intuitiva para reservas e informações de viagens.",
      tags: ["Frontend", "Integration", "Forms", "Accessibility"],
      icon: "map",
      category: "web",
      features: [
        "Integração direta com motor de busca do Booking.com",
        "Navegação clara e acessível",
        "Links sociais e formulários de contato otimizados",
        "Background imersivo com sobreposição de elementos"
      ]
    }
  ],
  experience: [
    {
      company: "EQUINIX",
      role: "Hosting Operations - Estágio",
      period: "Junho 2023 – Junho 2025",
      location: "Rio de Janeiro, Brasil",
      description: [
        "Garantia de disponibilidade de serviços de infraestrutura para clientes nacionais e internacionais.",
        "Implementação de templates customizados no Zabbix para monitoramento proativo de servidores Windows/Linux.",
        "Desenvolvimento de scripts em PowerShell e Bash para automação de resposta a incidentes.",
        "Administração e troubleshooting de servidores Windows e Linux, Active Directory e GPOs.",
        "Gerenciamento de VMs em Hyper-V e VMware e resolução de falhas de backup no Commvault.",
        "Gestão de incidentes via ServiceNow com foco em SLAs e relatórios gerenciais."
      ]
    }
  ],
  skills: [
    {
      category: "Active Directory",
      items: ["Admin AD DS", "GPO", "PowerShell", "DNS", "LDAP", "MFA"],
      icon: "users"
    },
    {
      category: "Sistemas Operacionais",
      items: ["Windows Server", "Linux (CentOS, Ubuntu)"],
      icon: "server"
    },
    {
      category: "Automação / Scripting",
      items: ["PowerShell", "Shell Script / Bash"],
      icon: "terminal"
    },
    {
      category: "Monitoramento",
      items: ["Zabbix", "Grafana", "Datadog"],
      icon: "activity"
    },
    {
      category: "Virtualização",
      items: ["Hyper-V", "VMware (ESXi)", "vCenter"],
      icon: "layers"
    },
    {
      category: "Infraestrutura",
      items: ["Commvault", "ServiceNow", "Cloud"],
      icon: "cloud"
    },
    {
      category: "Redes",
      items: ["Firewall Fortigate", "PfSense"],
      icon: "network"
    }
  ],
  education: [
    {
      institution: "Estácio",
      degree: "Ciência da Computação",
      period: "2022 – Presente",
      location: "EAD"
    }
  ],
  certifications: [
    { name: "Microsoft Azure Infraestrutura - Curso Completo", issuer: "Udemy" },
    { name: "Microsoft Windows Server 2019", issuer: "Udemy" },
    { name: "CCNA: Introduction to Networks", issuer: "Cisco" },
    { name: "Network Security", issuer: "Cisco" },
    { name: "CyberOps Associate", issuer: "Cisco" }
  ],
  languages: ["Inglês Fluente (Wise Up English Program)", "Português Nativo"]
};