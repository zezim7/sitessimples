export interface SocialLink {
  platform: string;
  url: string;
  icon: string;
}

export interface Experience {
  company: string;
  role: string;
  period: string;
  location: string;
  description: string[];
}

export interface SkillCategory {
  category: string;
  items: string[];
  icon: string;
}

export interface Education {
  institution: string;
  degree: string;
  period: string;
  location: string;
}

export interface Certification {
  name: string;
  issuer: string;
}

export interface Project {
  title: string;
  description: string;
  tags: string[];
  features: string[];
  icon: string;
  category: 'infra' | 'web';
}

export interface ProfileData {
  name: string;
  title: string;
  location: string;
  contact: {
    email: string;
    phone: string;
  };
  socials: SocialLink[];
  summary: string;
  experience: Experience[];
  skills: SkillCategory[];
  projects: Project[];
  education: Education[];
  certifications: Certification[];
  languages: string[];
}