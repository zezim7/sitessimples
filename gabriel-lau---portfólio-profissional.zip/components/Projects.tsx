import React from 'react';
import { Monitor, Shield, RefreshCw, Network, CheckCircle2, Globe, Palette, Map } from 'lucide-react';
import { RESUME_DATA } from '../constants';
import { motion, Variants } from 'framer-motion';
import { Project } from '../types';

const iconMap: Record<string, React.ReactNode> = {
  monitor: <Monitor size={32} />,
  shield: <Shield size={32} />,
  refresh: <RefreshCw size={32} />,
  network: <Network size={32} />,
  globe: <Globe size={32} />,
  palette: <Palette size={32} />,
  map: <Map size={32} />
};

const cardVariants: Variants = {
  hidden: { opacity: 0, y: 30 },
  visible: (index: number) => ({
    opacity: 1,
    y: 0,
    transition: {
      delay: index * 0.1,
      duration: 0.5,
      ease: "easeOut"
    }
  }),
  hover: {
    scale: 1.02,
    y: -5,
    boxShadow: "0 20px 30px -10px rgba(14, 165, 233, 0.15)", // Primary-500 glow effect
    transition: {
      duration: 0.2,
      ease: "easeInOut"
    }
  }
};

const ProjectCard: React.FC<{ project: Project; index: number }> = ({ project, index }) => (
  <motion.div 
    custom={index}
    variants={cardVariants}
    initial="hidden"
    whileInView="visible"
    whileHover="hover"
    viewport={{ once: true }}
    className="bg-dark-800 rounded-2xl overflow-hidden border border-slate-700/50 hover:border-primary-500/50 transition-colors group flex flex-col h-full"
  >
    <div className="p-8 flex-1">
      <div className="flex items-start justify-between mb-6">
        <div className="p-3 bg-primary-900/20 text-primary-400 rounded-xl group-hover:bg-primary-500 group-hover:text-white transition-colors duration-300">
          {iconMap[project.icon]}
        </div>
        <div className="flex flex-wrap gap-2 justify-end max-w-[60%]">
          {project.tags.map((tag, tIdx) => (
            <span key={tIdx} className="text-xs font-mono px-2 py-1 rounded bg-dark-950 text-slate-400 border border-slate-800">
              {tag}
            </span>
          ))}
        </div>
      </div>

      <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-primary-400 transition-colors">
        {project.title}
      </h3>
      <p className="text-slate-400 mb-6 leading-relaxed">
        {project.description}
      </p>

      <div className="space-y-3">
        {project.features.map((feature, fIdx) => (
          <div key={fIdx} className="flex items-start gap-3">
            <CheckCircle2 size={18} className="text-primary-500 mt-1 flex-shrink-0" />
            <span className="text-sm text-slate-300">{feature}</span>
          </div>
        ))}
      </div>
    </div>
    
    <div className="px-8 py-4 bg-dark-950/50 border-t border-slate-800 flex justify-between items-center">
      <span className="text-xs text-slate-500 font-mono">
        {project.category === 'infra' ? 'Infraestrutura & Scripting' : 'Frontend Development'}
      </span>
      <span className="text-xs font-medium text-primary-500 group-hover:translate-x-1 transition-transform cursor-default">
        Ver detalhes &rarr;
      </span>
    </div>
  </motion.div>
);

const Projects: React.FC = () => {
  const infraProjects = RESUME_DATA.projects.filter(p => p.category === 'infra');
  const webProjects = RESUME_DATA.projects.filter(p => p.category === 'web');

  return (
    <section className="py-20 bg-dark-900" id="projetos">
      <div className="container mx-auto px-4">
        
        {/* Infra Section */}
        <div className="mb-20">
          <div className="flex flex-col items-center mb-12">
            <h2 className="text-3xl font-bold text-white mb-4">Projetos em Zabbix & Automação</h2>
            <p className="text-slate-400 text-center max-w-2xl">
              Soluções de monitoramento e automação desenvolvidas para resolver problemas reais de infraestrutura, 
              focando em escalabilidade, segurança e self-healing.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {infraProjects.map((project, index) => (
              <ProjectCard key={index} project={project} index={index} />
            ))}
          </div>
        </div>

        {/* Web Section */}
        <div>
          <div className="flex flex-col items-center mb-12">
            <div className="w-20 h-1 bg-primary-500 rounded-full mb-8"></div>
            <h2 className="text-3xl font-bold text-white mb-4">Desenvolvimento Web & Frontend</h2>
            <p className="text-slate-400 text-center max-w-2xl">
              Projetos de desenvolvimento web focados em design moderno, responsividade e experiências digitais intuitivas.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {webProjects.map((project, index) => (
              <ProjectCard key={index} project={project} index={index + 5} />
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};

export default Projects;