import React from 'react';
import { Mail, Phone, MapPin, Download, Github, Linkedin, Terminal } from 'lucide-react';
import { RESUME_DATA } from '../constants';
import { motion } from 'framer-motion';

const Hero: React.FC = () => {
  return (
    <section className="relative pt-20 pb-16 md:pt-32 md:pb-24 overflow-hidden">
      {/* Background Decorator */}
      <div className="absolute top-0 left-1/2 w-full -translate-x-1/2 h-full z-0 pointer-events-none opacity-20">
        <div className="absolute top-10 right-10 w-72 h-72 bg-primary-500 rounded-full blur-[100px]"></div>
        <div className="absolute bottom-10 left-10 w-72 h-72 bg-purple-500 rounded-full blur-[100px]"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-12">
          
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="flex-1 text-center md:text-left"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary-900/50 border border-primary-700 text-primary-300 text-sm font-medium mb-6">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary-500"></span>
              </span>
              Disponível para novas oportunidades
            </div>
            
            <h1 className="text-4xl md:text-6xl font-bold text-white tracking-tight mb-4">
              {RESUME_DATA.name}
            </h1>
            <h2 className="text-xl md:text-2xl text-primary-400 font-medium mb-6 font-mono">
              &lt;{RESUME_DATA.title} /&gt;
            </h2>
            
            <p className="text-slate-300 text-lg leading-relaxed max-w-2xl mb-8 mx-auto md:mx-0">
              {RESUME_DATA.summary}
            </p>

            <div className="flex flex-wrap justify-center md:justify-start gap-4 mb-8">
              <a 
                href={`mailto:${RESUME_DATA.contact.email}`}
                className="flex items-center gap-2 px-6 py-3 bg-primary-600 hover:bg-primary-500 text-white rounded-lg font-medium transition-colors shadow-lg shadow-primary-900/50"
              >
                <Mail size={18} />
                Contato
              </a>
              <button 
                onClick={() => window.print()}
                className="flex items-center gap-2 px-6 py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg font-medium transition-colors"
              >
                <Download size={18} />
                Salvar PDF
              </button>
            </div>

            <div className="flex flex-col md:flex-row items-center gap-4 text-slate-400 text-sm">
              <div className="flex items-center gap-2">
                <MapPin size={16} className="text-primary-500" />
                {RESUME_DATA.location}
              </div>
              <div className="hidden md:block w-1 h-1 bg-slate-600 rounded-full"></div>
              <div className="flex items-center gap-2">
                <Phone size={16} className="text-primary-500" />
                {RESUME_DATA.contact.phone}
              </div>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="flex-shrink-0"
          >
             <div className="relative w-64 h-64 md:w-80 md:h-80 rounded-2xl overflow-hidden border-4 border-slate-700/50 shadow-2xl bg-slate-800 flex items-center justify-center group">
                {/* Simulated Terminal/Code Block */}
                <div className="absolute inset-0 bg-slate-900 p-4 font-mono text-xs md:text-sm text-slate-400 overflow-hidden opacity-90">
                    <div className="flex gap-2 mb-4 border-b border-slate-700 pb-2">
                        <div className="w-3 h-3 rounded-full bg-red-500"></div>
                        <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                        <div className="w-3 h-3 rounded-full bg-green-500"></div>
                    </div>
                    <p className="text-green-400">$ whoami</p>
                    <p className="mb-2">gabriel_lau</p>
                    <p className="text-green-400">$ current_status</p>
                    <p className="mb-2">"Open to Work / Disponível"</p>
                    <p className="text-green-400">$ skills</p>
                    <p className="mb-2">[Zabbix, Windows Server, Linux Shell, PfSense, Fortigate, Active Directory]</p>
                    <p className="text-green-400">$ last_login</p>
                    <p className="animate-pulse">_</p>
                </div>
                <div className="absolute bottom-0 w-full h-1/3 bg-gradient-to-t from-primary-900/40 to-transparent"></div>
             </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
};

export default Hero;