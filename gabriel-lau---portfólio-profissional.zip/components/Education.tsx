import React from 'react';
import { GraduationCap, Award, Globe } from 'lucide-react';
import { RESUME_DATA } from '../constants';

const Education: React.FC = () => {
  return (
    <section className="py-20 bg-dark-800" id="formacao">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12">
          
          {/* Education Column */}
          <div>
            <h2 className="text-2xl font-bold text-white mb-8 flex items-center gap-3 border-b border-slate-700 pb-4">
              <GraduationCap className="text-primary-500" />
              Formação Acadêmica
            </h2>
            <div className="space-y-6">
              {RESUME_DATA.education.map((edu, index) => (
                <div key={index} className="bg-dark-900 p-6 rounded-xl border border-slate-700">
                  <h3 className="text-lg font-bold text-white mb-1">{edu.degree}</h3>
                  <p className="text-primary-400 font-medium mb-2">{edu.institution}</p>
                  <div className="flex justify-between text-sm text-slate-400">
                    <span>{edu.period}</span>
                    <span>{edu.location}</span>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-12">
                <h2 className="text-2xl font-bold text-white mb-8 flex items-center gap-3 border-b border-slate-700 pb-4">
                <Globe className="text-primary-500" />
                Idiomas
                </h2>
                <div className="space-y-3">
                    {RESUME_DATA.languages.map((lang, index) => (
                        <div key={index} className="flex items-center gap-3 text-slate-200">
                            <div className="w-2 h-2 rounded-full bg-green-500"></div>
                            {lang}
                        </div>
                    ))}
                </div>
            </div>
          </div>

          {/* Certifications Column */}
          <div>
            <h2 className="text-2xl font-bold text-white mb-8 flex items-center gap-3 border-b border-slate-700 pb-4">
              <Award className="text-primary-500" />
              Certificações
            </h2>
            <div className="grid gap-4">
              {RESUME_DATA.certifications.map((cert, index) => (
                <div key={index} className="flex items-start gap-4 p-4 rounded-lg bg-dark-900/50 hover:bg-dark-900 transition-colors border border-slate-800 hover:border-slate-600">
                  <div className="p-2 bg-slate-800 rounded text-yellow-500">
                    <Award size={20} />
                  </div>
                  <div>
                    <h3 className="text-white font-medium">{cert.name}</h3>
                    <p className="text-sm text-slate-400 mt-1">{cert.issuer}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Education;