import React from 'react';
import { Briefcase, Calendar, MapPin } from 'lucide-react';
import { RESUME_DATA } from '../constants';
import { motion } from 'framer-motion';

const Experience: React.FC = () => {
  return (
    <section className="py-20 bg-dark-900" id="experiencia">
      <div className="container mx-auto px-4 max-w-4xl">
        <h2 className="text-3xl font-bold text-white mb-12 flex items-center gap-3">
          <Briefcase className="text-primary-500" />
          Experiência Profissional
        </h2>

        <div className="space-y-12">
          {RESUME_DATA.experience.map((job, index) => (
            <motion.div 
              key={index}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative pl-8 md:pl-0"
            >
              {/* Timeline Line (Desktop) */}
              <div className="hidden md:block absolute left-0 top-0 bottom-0 w-px bg-slate-800 md:left-[140px]"></div>

              <div className="md:flex gap-8 group">
                {/* Date Column */}
                <div className="md:w-[140px] flex-shrink-0 pt-2 mb-4 md:mb-0 relative">
                  <div className="md:text-right">
                    <span className="text-sm font-bold text-primary-400 block mb-1">
                      {job.period.split('–')[1]?.trim() || 'Presente'}
                    </span>
                    <span className="text-xs text-slate-500">
                      {job.period.split('–')[0]?.trim()}
                    </span>
                  </div>
                  {/* Timeline Dot */}
                  <div className="hidden md:block absolute right-[-5px] top-3 w-2.5 h-2.5 rounded-full bg-primary-500 border-2 border-dark-900 z-10 group-hover:scale-125 transition-transform"></div>
                </div>

                {/* Content Card */}
                <div className="flex-1 bg-dark-800 p-6 rounded-2xl border border-slate-700/50 hover:border-slate-600 transition-colors">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4 gap-2">
                    <div>
                      <h3 className="text-xl font-bold text-white">{job.role}</h3>
                      <h4 className="text-lg text-primary-300">{job.company}</h4>
                    </div>
                    <div className="flex items-center gap-2 text-slate-400 text-sm">
                      <MapPin size={14} />
                      {job.location}
                    </div>
                  </div>

                  <ul className="space-y-3">
                    {job.description.map((point, idx) => (
                      <li key={idx} className="flex gap-3 text-slate-300 leading-relaxed">
                        <span className="mt-2 w-1.5 h-1.5 rounded-full bg-primary-500 flex-shrink-0 opacity-70"></span>
                        <span>{point}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Experience;