import React from 'react';
import { Server, Terminal, Activity, Layers, Cloud, Network, Users } from 'lucide-react';
import { RESUME_DATA } from '../constants';
import { motion } from 'framer-motion';

const iconMap: Record<string, React.ReactNode> = {
  server: <Server size={24} />,
  terminal: <Terminal size={24} />,
  activity: <Activity size={24} />,
  layers: <Layers size={24} />,
  cloud: <Cloud size={24} />,
  network: <Network size={24} />,
  users: <Users size={24} />
};

const Skills: React.FC = () => {
  return (
    <section className="py-20 bg-dark-800" id="competencias">
      <div className="container mx-auto px-4">
        <div className="flex items-center gap-4 mb-12">
           <div className="h-1 flex-1 bg-slate-700 rounded-full"></div>
           <h2 className="text-3xl font-bold text-white text-center">Principais Competências</h2>
           <div className="h-1 flex-1 bg-slate-700 rounded-full"></div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {RESUME_DATA.skills.map((skillGroup, index) => (
            <motion.div 
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-dark-900 p-6 rounded-xl border border-slate-700 hover:border-primary-500/50 hover:shadow-lg hover:shadow-primary-900/20 transition-all group"
            >
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 bg-slate-800 rounded-lg text-primary-400 group-hover:text-primary-300 group-hover:bg-primary-900/30 transition-colors">
                  {iconMap[skillGroup.icon]}
                </div>
                <h3 className="text-xl font-semibold text-slate-100">{skillGroup.category}</h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {skillGroup.items.map((item, idx) => (
                  <span 
                    key={idx} 
                    className="px-3 py-1 bg-slate-800 text-slate-300 rounded text-sm font-mono border border-slate-700"
                  >
                    {item}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;