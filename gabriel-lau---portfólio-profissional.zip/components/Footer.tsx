import React from 'react';
import { RESUME_DATA } from '../constants';
import { Github, Linkedin, Mail } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-dark-950 py-12 border-t border-slate-800">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-2xl font-bold text-white mb-2">{RESUME_DATA.name}</h2>
        <p className="text-slate-400 mb-8">{RESUME_DATA.title}</p>
        
        <div className="flex justify-center gap-6 mb-8">
            <a href={`mailto:${RESUME_DATA.contact.email}`} className="text-slate-400 hover:text-white transition-colors">
                <Mail />
            </a>
            {RESUME_DATA.socials.map((social, idx) => {
                if(social.platform === "GitHub") return <a key={idx} href={social.url} className="text-slate-400 hover:text-white transition-colors"><Github /></a>
                if(social.platform === "LinkedIn") return <a key={idx} href={social.url} className="text-slate-400 hover:text-white transition-colors"><Linkedin /></a>
                return null;
            })}
        </div>
        
        <p className="text-slate-600 text-sm">
          © {new Date().getFullYear()} Gabriel Lau. Todos os direitos reservados.
        </p>
      </div>
    </footer>
  );
};

export default Footer;